#!/usr/bin/env python3
# Generates 3 result-based one-page nutrition guides for CGFIT365 / purposerx.health
# Each "Get the Plan" button is a clickable Stripe checkout link inside the PDF.
import os
from playwright.sync_api import sync_playwright

OUT = "/home/claude"
BRAND = "CGFIT365"
SITE  = "purposerx.health"

# ---- EDIT prices / copy / Stripe links here ----
TIERS = {
    "starter": {
        "result": "Starter",
        "stripe": "https://buy.stripe.com/cNi7sL18K1qZ91lcmt1RC02",
        "h1_top": "The 1-Page",
        "h1_bottom": "Nutrition System",
        "sub": ("Most plans drown you in rules. This one runs on <b>three dials</b> you can set today "
                "and repeat forever. Master these and 90% of nutrition takes care of itself "
                "&mdash; no tracking spirals, no guesswork."),
        "cta_label": "Your Gap: Structure",
        "cta_h2": 'You\'ve got the <span class="g">fuel</span>.<br>Now get the <span class="g">training plan</span>.',
        "cta_p": ("You've got the nutrition basics right here. The <b>Starter Plan</b> gives you the training "
                  "structure to match &mdash; a beginner-friendly 4-week workout plan with weekly structure, "
                  "sets, reps, and rest, so you walk into the gym knowing exactly what to do and why."),
        "plan_name": "Get the Starter Plan",
        "price": "$30 &middot; 4-week plan",
        "inside_title": "Inside the Starter Plan",
        "inside": ["4-week beginner workout plan", "Weekly training structure",
                   "Sets, reps &amp; rest guidance", "Beginner-friendly exercises"],
    },
    "transformation": {
        "result": "Transformation",
        "stripe": "https://buy.stripe.com/3cI6oH18KedLfpJ5Y51RC00",
        "h1_top": "Where Nutrition",
        "h1_bottom": "Meets Training",
        "sub": ("You're ready to pair eating with a real plan. The same <b>three dials</b> run your nutrition &mdash; "
                "now the win is putting <b>food and training on the same page</b>, pulling toward one clear goal "
                "instead of fighting each other."),
        "cta_label": "Your Gap: Training + Nutrition Together",
        "cta_h2": 'Eating right is <span class="g">half</span> the result.<br>Pair it with a <span class="g">plan that trains</span>.',
        "cta_p": ("The <b>Transformation Plan</b> combines this nutrition approach with a goal-based 4-week training "
                  "plan &mdash; whether you're losing fat, building muscle, or both. Protein and meal structure "
                  "guidance built in, so what you eat and how you train finally line up."),
        "plan_name": "Get the Transformation Plan",
        "price": "$40 &middot; 4-week plan",
        "inside_title": "Inside the Transformation Plan",
        "inside": ["4-week goal-based training plan", "Nutrition guidance built in",
                   "Protein &amp; meal structure tips", "Fat-loss or muscle focus"],
    },
    "purpose": {
        "result": "Purpose",
        "stripe": "https://buy.stripe.com/00w9ATbNofhPcdx2LT1RC01",
        "h1_top": "The Complete",
        "h1_bottom": "Purpose System",
        "sub": ("Nutrition is the foundation &mdash; but lasting change is <b>training, fuel, recovery, and "
                "discipline working together</b>. The three dials get your eating right; the full system makes "
                "every part pull in the same direction."),
        "cta_label": "Your Gap: The Whole System",
        "cta_h2": 'Nutrition is <span class="g">one piece</span>.<br>The Purpose Plan is <span class="g">all of them</span>.',
        "cta_p": ("The <b>Purpose Plan</b> brings together training, nutrition, recovery, and faith-based discipline "
                  "in one 4-week system &mdash; built so every session and every meal has a reason behind it. "
                  "Structured to keep you consistent. <b>Strengthened by faith.</b>"),
        "plan_name": "Get the Purpose Plan",
        "price": "$60 &middot; 4-week plan",
        "inside_title": "Inside the Purpose Plan",
        "inside": ["4-week training + nutrition plan", "Recovery habits that stick",
                   "Faith-based mindset focus", "Weekly check-in guidance"],
    },
}

DIALS = [
    ("01", "Protein", "The anchor of every meal.",
     ["Aim for <b>~0.7&ndash;1g per lb</b> of bodyweight, spread across the day.",
      "<b>Eat it first.</b> Protein blunts hunger and protects muscle while you train.",
      "A palm-sized portion at <b>each</b> meal hits the target without math."]),
    ("02", "Plate", "Structure beats willpower.",
     ["<b>Half</b> the plate: vegetables &amp; fruit (volume + fiber).",
      "<b>A quarter:</b> protein. <b>A quarter:</b> smart carbs &mdash; rice, oats, potato.",
      "Add <b>a thumb of fats</b> &mdash; oil, nuts, avocado. Same plate, win on autopilot."]),
    ("03", "Pattern", "Consistency is the multiplier.",
     ["Run <b>3&ndash;4 meals you actually like</b> on repeat. Boring is what works.",
      "Drink <b>water before you snack</b> &mdash; most cravings are thirst in disguise.",
      "Live at <b>80/20</b>: dialed all week, flexible without guilt on the edges."]),
]
TOMORROW = [
    ("1. Anchor breakfast", "Hit 30g+ protein before noon."),
    ("2. Build one plate", "Use the half / quarter / quarter rule once."),
    ("3. Fill a bottle", "Finish it before your first snack."),
]

CSS = """
  @page { size: 8.5in 11in; margin: 0; }
  * { margin:0; padding:0; box-sizing:border-box; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
  :root{ --bg:#0a0a0b; --panel:#141417; --panel2:#1a1a1e; --line:#262629;
    --gold:#F4A823; --gold-bright:#FFB531; --ember:#FF6A00; --red:#C21807;
    --text:#ededed; --muted:#9c9ca1; --faint:#6a6a70;
    --sans:"Liberation Sans","Helvetica Neue",Arial,sans-serif;
    --disp:"DejaVu Sans","Liberation Sans",Arial,sans-serif; }
  html,body{ width:8.5in; height:11in; }
  body{ background:var(--bg); color:var(--text); font-family:var(--sans); position:relative; overflow:hidden; }
  a{ text-decoration:none; color:inherit; }
  .page{ position:relative; width:8.5in; height:11in; padding:0.46in 0.5in 0 0.5in; display:flex; flex-direction:column; }
  .page:before{ content:""; position:absolute; top:-1.2in; left:50%; transform:translateX(-50%);
    width:7in; height:2.4in; border-radius:50%;
    background:radial-gradient(ellipse at center, rgba(244,168,35,.10), rgba(244,168,35,0) 70%); pointer-events:none; }
  .topbar{ display:flex; justify-content:space-between; align-items:baseline; }
  .wordmark{ font-family:var(--disp); font-weight:700; font-size:9.5pt; letter-spacing:3px; color:var(--gold); text-transform:uppercase; }
  .site{ font-size:8pt; letter-spacing:1.5px; color:var(--faint); text-transform:lowercase; }
  .rule{ height:2px; margin-top:7px; background:linear-gradient(90deg,var(--gold),rgba(244,168,35,0)); }
  .hero{ margin-top:15px; }
  .heroline{ display:flex; align-items:center; gap:11px; }
  .kicker{ font-family:var(--disp); font-weight:700; font-size:8pt; letter-spacing:5px; color:var(--ember); text-transform:uppercase; }
  .resultpill{ font-family:var(--disp); font-weight:700; font-size:7pt; letter-spacing:2px; text-transform:uppercase;
    color:var(--gold-bright); border:1px solid var(--gold); border-radius:20px; padding:3px 11px; background:rgba(244,168,35,.08); white-space:nowrap; }
  h1{ font-family:var(--disp); font-weight:700; text-transform:uppercase; font-size:30pt; line-height:0.97; letter-spacing:-0.5px; margin-top:7px; color:#fff; }
  h1 .g{ color:var(--gold); }
  .sub{ margin-top:9px; font-size:10.5pt; line-height:1.35; color:var(--muted); max-width:6.5in; }
  .sub b{ color:var(--text); font-weight:600; }
  .cred{ margin-top:13px; display:flex; align-items:center; gap:10px; background:var(--panel); border:1px solid var(--line);
    border-left:3px solid var(--gold); border-radius:6px; padding:9px 13px; }
  .cred .by{ font-size:9pt; color:var(--text); line-height:1.3; }
  .cred .by b{ color:var(--gold-bright); }
  .cred .tags{ margin-left:auto; display:flex; gap:6px; flex-shrink:0; }
  .tag{ font-size:6.8pt; letter-spacing:1px; text-transform:uppercase; color:var(--muted); border:1px solid var(--line); border-radius:20px; padding:3px 8px; white-space:nowrap; }
  .seclabel{ display:flex; align-items:center; gap:9px; margin:16px 0 11px; }
  .seclabel .n{ font-family:var(--disp); font-weight:700; font-size:9pt; letter-spacing:3px; color:var(--gold); text-transform:uppercase; white-space:nowrap; }
  .seclabel .ln{ flex:1; height:1px; background:var(--line); }
  .seclabel .note{ font-size:7.5pt; color:var(--faint); letter-spacing:1px; text-transform:uppercase; }
  .dials{ display:grid; grid-template-columns:1fr 1fr 1fr; gap:11px; }
  .dial{ background:var(--panel); border:1px solid var(--line); border-radius:9px; padding:13px 13px 14px; position:relative; overflow:hidden; }
  .dial:before{ content:""; position:absolute; top:0; left:0; right:0; height:2px; background:linear-gradient(90deg,var(--gold),var(--ember)); opacity:.85; }
  .dial .num{ font-family:var(--disp); font-weight:700; font-size:13pt; color:var(--gold); line-height:1; }
  .dial .name{ font-family:var(--disp); font-weight:700; text-transform:uppercase; font-size:13.5pt; letter-spacing:0.5px; color:#fff; margin-top:5px; line-height:1; }
  .dial .one{ font-size:8.6pt; color:var(--gold-bright); font-weight:600; margin-top:6px; line-height:1.25; }
  .dial ul{ list-style:none; margin-top:9px; }
  .dial li{ font-size:8.4pt; color:var(--muted); line-height:1.4; padding-left:13px; position:relative; margin-bottom:5px; }
  .dial li:last-child{ margin-bottom:0; }
  .dial li:before{ content:""; position:absolute; left:0; top:6px; width:5px; height:5px; background:var(--ember); border-radius:50%; }
  .dial li b{ color:var(--text); font-weight:600; }
  .tom{ margin-top:13px; background:linear-gradient(180deg,var(--panel2),var(--panel)); border:1px solid var(--line); border-radius:9px; padding:12px 15px; display:flex; align-items:center; gap:16px; }
  .tom .lead .t{ font-family:var(--disp); font-weight:700; text-transform:uppercase; font-size:11pt; letter-spacing:1px; color:#fff; line-height:1; }
  .tom .lead .s{ font-size:7.5pt; color:var(--faint); letter-spacing:1px; text-transform:uppercase; margin-top:4px; }
  .tom .steps{ display:flex; gap:14px; flex:1; }
  .tom .step{ font-size:8.4pt; color:var(--muted); line-height:1.35; flex:1; }
  .tom .step b{ color:var(--gold-bright); display:block; font-size:8.6pt; margin-bottom:2px; font-weight:700; }
  .cta{ margin-top:14px; border:1.5px solid var(--gold); border-radius:11px;
    background: radial-gradient(ellipse at 85% 120%, rgba(255,106,0,.18), rgba(255,106,0,0) 60%), linear-gradient(180deg,#161616,#101010);
    padding:15px 18px; display:flex; align-items:center; gap:18px; }
  .cta .left{ flex:1; }
  .cta .glabel{ font-family:var(--disp); font-weight:700; font-size:7.5pt; letter-spacing:3px; color:var(--ember); text-transform:uppercase; }
  .cta h2{ font-family:var(--disp); font-weight:700; text-transform:uppercase; color:#fff; font-size:14pt; line-height:1.04; letter-spacing:-0.2px; margin-top:5px; }
  .cta h2 .g{ color:var(--gold); }
  .cta p{ font-size:8.8pt; color:var(--muted); line-height:1.4; margin-top:7px; max-width:4.6in; }
  .cta p b{ color:var(--text); font-weight:600; }
  .cta .right{ flex-shrink:0; text-align:center; }
  .pill{ display:inline-block; text-decoration:none; background:linear-gradient(180deg,var(--gold-bright),var(--gold)); color:#1a1300;
    font-family:var(--disp); font-weight:700; text-transform:uppercase; font-size:10pt; letter-spacing:0.3px;
    padding:11px 18px; border-radius:8px; box-shadow:0 4px 14px rgba(244,168,35,.28); white-space:nowrap; }
  .pill .price{ font-size:7.5pt; display:block; font-weight:700; letter-spacing:1px; color:#3a2c00; margin-top:2px; }
  .cta .right .q{ font-size:7.6pt; color:var(--faint); margin-top:8px; letter-spacing:.5px; }
  .cta .right .q b{ color:var(--gold-bright); }
  .inside{ margin-top:13px; display:flex; align-items:center; gap:14px; padding:0 2px; }
  .inside .ititle{ font-family:var(--disp); font-weight:700; text-transform:uppercase; font-size:8pt; letter-spacing:1.2px; color:var(--gold); white-space:nowrap; flex-shrink:0; }
  .inside .iitems{ display:flex; gap:13px; flex:1; flex-wrap:wrap; }
  .inside .i{ font-size:7.9pt; color:var(--muted); display:flex; align-items:center; gap:5px; }
  .inside .ck{ color:var(--ember); font-weight:700; font-size:8pt; }
  .spacer{ flex:1; }
  .fire{ position:relative; height:1.18in; margin:0 -0.5in 0; flex-shrink:0;
    background: radial-gradient(120% 140% at 20% 130%, rgba(255,181,49,.95), rgba(255,181,49,0) 55%),
      radial-gradient(120% 150% at 78% 135%, rgba(255,106,0,.9), rgba(255,106,0,0) 55%),
      linear-gradient(0deg, #FFB531 0%, #FF6A00 38%, #C21807 66%, rgba(194,24,7,0) 100%); }
  .fire .tagwrap{ position:absolute; bottom:18px; left:0; right:0; text-align:center; }
  .firetag{ font-family:var(--disp); font-weight:700; text-transform:uppercase; font-size:11pt; letter-spacing:1px; color:#2a0f00; }
  .firetag .em{ color:#5a2400; }
  .firesub{ font-size:7.5pt; letter-spacing:2px; text-transform:uppercase; color:#5a2400; margin-top:6px; font-weight:600; }
"""

def build_html(t):
    dials_html = ""
    for num, name, one, lis in DIALS:
        lis_html = "".join(f"<li>{x}</li>" for x in lis)
        dials_html += f'<div class="dial"><div class="num">{num}</div><div class="name">{name}</div><div class="one">{one}</div><ul>{lis_html}</ul></div>'
    steps_html = "".join(f'<div class="step"><b>{a}</b>{b}</div>' for a, b in TOMORROW)
    inside_html = "".join(f'<div class="i"><span class="ck">&#10003;</span> {x}</div>' for x in t["inside"])
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><style>{CSS}</style></head><body>
  <div class="page">
    <div class="topbar"><div class="wordmark">{BRAND}</div><div class="site">{SITE}</div></div>
    <div class="rule"></div>
    <div class="hero">
      <div class="heroline"><span class="kicker">Fuel With Purpose</span><span class="resultpill">Your Result &middot; {t['result']}</span></div>
      <h1>{t['h1_top']}<br><span class="g">{t['h1_bottom']}</span></h1>
      <div class="sub">{t['sub']}</div>
    </div>
    <div class="cred">
      <div class="by">Built by <b>Carlos</b> &mdash; Pharmacy Student &amp; Coach. Grounded in how your body actually absorbs and uses fuel, not gym-floor myth.</div>
      <div class="tags"><span class="tag">Evidence-based</span><span class="tag">No fads</span><span class="tag">Repeatable</span></div>
    </div>
    <div class="seclabel"><span class="n">The Fuel Formula</span><span class="ln"></span><span class="note">Three dials. That's it.</span></div>
    <div class="dials">{dials_html}</div>
    <div class="tom"><div class="lead"><div class="t">Do This Tomorrow</div><div class="s">Start small &middot; win today</div></div><div class="steps">{steps_html}</div></div>
    <div class="cta"><div class="left">
        <div class="glabel">{t['cta_label']}</div><h2>{t['cta_h2']}</h2><p>{t['cta_p']}</p></div>
      <div class="right">
        <a class="pill" href="{t['stripe']}">{t['plan_name']}<span class="price">{t['price']}</span></a>
        <div class="q">More plans &amp; the quiz at<br><b>{SITE}</b></div></div></div>
    <div class="inside"><div class="ititle">{t['inside_title']}</div><div class="iitems">{inside_html}</div></div>
    <div class="spacer"></div>
    <div class="fire"><div class="tagwrap">
      <div class="firetag">Built through discipline. <span class="em">Strengthened by faith.</span></div>
      <div class="firesub">{BRAND} &middot; {SITE}</div></div></div>
  </div></body></html>"""

def main():
    p = sync_playwright().start(); b = p.chromium.launch()
    for key, t in TIERS.items():
        hp = f"{OUT}/guide_{key}.html"; pp = f"{OUT}/Fuel_With_Purpose_{t['result']}.pdf"
        open(hp, "w").write(build_html(t))
        pg = b.new_page(); pg.goto(f"file://{hp}"); pg.emulate_media(media="print")
        pg.pdf(path=pp, width="8.5in", height="11in", print_background=True,
               margin={"top":"0","bottom":"0","left":"0","right":"0"})
        pg.close(); print("built", pp)
    b.close(); p.stop()

if __name__ == "__main__":
    main()
